<?php // Silence is golden

echo "SHOULD not happen, indeed, you should have an access denied or blank page for those assets";